// ================== question 1 ================== //
// let number = 10;
// console.log(number);


// ================== question 2 ================== //
// let number = 12
// if (number % 3 == 0 && number % 4 == 0) {
//     console.log("Yes");
// } else {
//     console.log("No");
// }

// ================== question 3 ================== //
// let max = 50
// let min = 10
// if (max > min) {
//     console.log(max);
// } else {
//     console.log(min);
// }

// ================== question 4 ================== //
// let number = -5
// if(number>0){
//     console.log("The number is positive");
// }else
// {
//     console.log("The number is Negative");
// }

// ================== question 5 ================== //
// let firstNum = 1
// let secondNum = 2
// let ThirdNum = 3
// if (firstNum > secondNum && firstNum > ThirdNum) {
//     console.log("first number is max number");
// } else if (secondNum > firstNum && secondNum > ThirdNum) {
//     console.log("second number is max number");
// } else {
//     console.log("third number is max number");
// }

// ================== question 6 & 7 ================== //
// let number = 10
// if (number % 2 == 0) {
//     console.log("number is even");
// } else {
//     console.log("number is odd");
// }

// ================== question 8 ================== //
// let char = "O"
// if (char == "a" || char == "e" || char == "i" || char == "o" || char == "u") {
//     console.log("vowel & char are lower case");
// } else if (char == "A" || char == "E" || char == "I" || char == "O" || char == "U") {
//     console.log("vowel & char are upper case");
// } else {
//     console.log("consonant");
// }

// ================== question 9 ================== //
// let number = 5
// for (let i = 1; i <= number; i++) {
//     console.log(i);
// }

// ================== question 10 ================== //
// let table = 5
// for (let i = 1; i <= 12; i++) {
//     console.log(i * table);
// }

// ================== question 11 ================== //
// let number = 15
// for (let i = 1; i <= number; i++) {
//     if (i % 2 == 0) {
//         console.log(i);
//     }
// }

// ================== question 12 ================== //
// let number = 2;
// let power = 5;
// let result = 1;
// // hard solution
// for (let i = 1; i <= power; i++) {
//     result *= number
//     if (i == power) {
//         console.log(result);
//     }
// }
// // easy solution
// console.log(number ** power);

// ================== question 13 ================== //
// let monthNumber = 4;
// if (monthNumber == 1 || monthNumber == 3 || monthNumber == 5 || monthNumber == 7 || monthNumber == 8 || monthNumber == 10 || monthNumber == 12) {
//     console.log("Days in Month: 31");
// } else if (monthNumber == 4 || monthNumber == 6 || monthNumber == 9 || monthNumber == 11) {
//     console.log("Days in Month: 30");
// } else if (monthNumber == 2) {
//     console.log("Days in Month: 28 (29 in leap years)");
// } else {
//     console.log("Wrong Number => Accepted Value start form 1 to 12 ");
// }

// ================== question 14 ================== //

/*
explain the answer
we have 5 subject , every subject have 100 point
percentage => The sum of the five subjects / 500 * 100
*/

/* subjects */
// let physics = 80;
// let Chemistry = 75;
// let Biology = 90;
// let Mathematics = 65;
// let Computer = 100;
// /* marks*/
// let totalMark = 500
// let currentMark = physics + Chemistry + Biology + Mathematics + Computer
// let percentageMark = (currentMark / totalMark * 100)
// /* check percentageMark  */
// if (percentageMark >= 90) {
//     console.log("Grad A", percentageMark + "%");
// } else if (percentageMark >= 80) {
//     console.log("Grad B", percentageMark + "%");
// } else if (percentageMark >= 70) {
//     console.log("Grad C", percentageMark + "%");
// } else if (percentageMark >= 60) {
//     console.log("Grad D", percentageMark + "%");
// } else if (percentageMark >= 40) {
//     console.log("Grad E", percentageMark + "%");
// } else {
//     console.log("Grad F", percentageMark + "%");
// }

// ================== question 15 ================== //
// let monthNumber = 2
// switch (monthNumber) {
//     case 1:
//         console.log("Days in Month: 31");
//         break;
//     case 2:
//         console.log("Days in Month: 28 (29 in leap years)");
//         break;
//     case 3:
//         console.log("Days in Month: 31");
//         break;
//     case 4:
//         console.log("Days in Month: 30");
//         break;
//     case 5:
//         console.log("Days in Month: 31");
//         break;
//     case 6:
//         console.log("Days in Month: 30");
//         break;
//     case 7:
//         console.log("Days in Month: 31");
//         break;
//     case 8:
//         console.log("Days in Month: 31");
//         break;
//     case 9:
//         console.log("Days in Month: 30");
//         break;
//     case 10:
//         console.log("Days in Month: 31");
//         break;
//     case 11:
//         console.log("Days in Month: 30");
//         break;
//     case 12:
//         console.log("Days in Month: 31");
//         break;

//     default:
//         console.log("Wrong Number => Accepted Value start form 1 to 12 ");
//         break;
// }

// ================== question 16 ================== //
// let char = "k"
// switch (char) {
//     // vowel and upper case
//     case "A":
//         console.log("vowel & char are upper case");
//         break;
//     case "E":
//         console.log("vowel & char are upper case");
//         break;
//     case "I":
//         console.log("vowel & char are upper case");
//         break;
//     case "O":
//         console.log("vowel & char are upper case");
//         break;
//     case "U":
//         console.log("vowel & char are upper case");
//         break;
//     // vowel and lower case
//     case "a":
//         console.log("vowel & char are lower case");
//         break;
//     case "e":
//         console.log("vowel & char are lower case");
//         break;
//     case "i":
//         console.log("vowel & char are lower case");
//         break;
//     case "o":
//         console.log("vowel & char are lower case");
//         break;
//     case "u":
//         console.log("vowel & char are lower case");
//         break;
//     // consonant
//     default:
//         console.log("consonant");
//         break;
// }

// ================== question 17 ================== //
// let num = 100
// let number2 = 200

// switch (number1 > number2) {
//     case true:
//         console.log(number1);
//         break;

//     case false:
//         console.log(number2);
//         break;
// }

// ================== question 18 ================== //
// let num = 9
// switch (num % 2 == 0) {
//     case true:
//         console.log("even number");
//         break;

//     case false:
//         console.log("odd number");
//         break;
// }

// ================== question 19 ================== //
// let num = 0
// switch (num >= 0) {
//     case true:
//         switch (num == 0) {
//             case true:
//                 console.log("number is zero");
//                 break;
//             case false:
//                 console.log("number is positive");
//                 break;
//         }
//         break;
//     case false:
//         console.log("number is negative");
//         break;
// }

// ================== question 20 ================== //
// let num1 = 5
// let num2 = 10
// let operator = "+"
// switch (operator) {
//     case "+":
//         console.log(num1 + num2);
//         break;
//     case "-":
//         console.log(num1 - num2);
//         break;
//     case "*":
//         console.log(num1 * num2);
//         break;
//     case "/":
//         console.log(num1 / num2);
//         break;

//     default:
//         console.log("worng operator => calculator accept +, -, * and /");
//         break;
// }